(() => {
  "use strict";
  const BUILD_VERSION="14.4.3";
  const SUPPORT_SCRIPTS=["data.js","enos-data.js","enos-reviews.js","risk-locations.js","f03-data.js","cases-data.js","pilot-baseline-bridge.js"];
  const $=selector=>document.querySelector(selector);
  const normalizeEmail=value=>String(value||"").trim().toLowerCase();
  const normalizeState=value=>String(value||"").trim().toLowerCase();
  let loaded=false,loading=false,pendingLoginMessage="";

  function loginMessage(message=""){
    if($("#loginError")) $("#loginError").textContent=message;
  }
  function rememberLoginMessage(message=""){
    pendingLoginMessage=message||pendingLoginMessage||"";
    loginMessage(pendingLoginMessage);
  }
  function showLogin(message){
    $("#app")?.classList.add("hidden");
    $("#login")?.classList.remove("hidden");
    $("#guideHelp")?.classList.add("hidden");
    $("#riskAnalyst")?.classList.add("hidden");
    if(message!==undefined) pendingLoginMessage=message||"";
    loginMessage(pendingLoginMessage);
  }
  function status(text,state="local"){
    if($("#syncStatus")){
      $("#syncStatus").textContent=text;
      $("#syncStatus").className=`sync-status ${state}`;
    }
  }
  function setLoginBusy(busy){
    const button=$("#loginForm button");
    if(!button) return;
    button.disabled=Boolean(busy);
    button.textContent=busy?"Ingresando…":"Ingresar";
  }
  function authErrorMessage(error){
    const code=String(error?.code||"");
    if(["auth/invalid-credential","auth/wrong-password","auth/user-not-found","auth/invalid-login-credentials"].includes(code)) return "Correo o contraseña incorrectos.";
    if(code==="auth/user-disabled") return "La cuenta está deshabilitada en Firebase Authentication.";
    if(code==="auth/too-many-requests") return "Se bloquearon temporalmente los intentos. Espera unos minutos o restablece la contraseña.";
    if(code==="auth/network-request-failed") return "No fue posible conectarse con Firebase Authentication. Revisa la red institucional.";
    if(code==="auth/unauthorized-domain") return "Este dominio no está autorizado en Firebase Authentication.";
    return `No fue posible iniciar sesión${code?` (${code})`:""}.`;
  }
  function loadScript(src){
    return new Promise((resolve,reject)=>{
      const script=document.createElement("script");
      script.src=`${src}?v=${BUILD_VERSION}`;
      script.async=false;
      script.onload=resolve;
      script.onerror=()=>reject(new Error(`No fue posible cargar ${src}`));
      document.body.appendChild(script);
    });
  }
  async function readProfile(user){
    const snap=await db.collection("perfiles").doc(user.uid).get();
    return snap.exists?snap.data():null;
  }
  async function loadApplication(user,profile){
    if(loaded||loading)return;
    loading=true;
    try{
      status("Preparando alcance territorial...","saving");
      if(!window.SmartRiskScope||!window.SmartRiskScopeRepository) throw new Error("Módulos de alcance no disponibles");
      window.SmartRiskScope.init({user,profile,db,auth});
      for(const src of SUPPORT_SCRIPTS) await loadScript(src);
      if(!window.SEED_DATA) throw new Error("Datos base no disponibles");
      await window.SmartRiskScopeRepository.init({user,profile,db,auth});
      status(`Cargando ${window.SmartRiskScope.scopeLabel()}...`,"saving");
      await loadScript("app.js");
      loaded=true;
      pendingLoginMessage="";
      window.SMART_RISK_AUTH_DIAGNOSTIC={stage:"application-loaded",email:user.email,uid:user.uid,profileState:profile.estado,at:new Date().toISOString()};
    }catch(error){
      console.error("SmartRisk RC14.4.3 no pudo iniciar",error);
      status("Error de carga RC14.4.3","conflict");
      const content=document.querySelector("#content");
      if(content) content.innerHTML=`<section class="panel"><h3>No fue posible iniciar SmartRisk RC14.4.3</h3><p>${String(error.message||error)}</p><p>Recarga con Ctrl+F5. Si persiste, reporta esta pantalla al administrador.</p></section>`;
      document.querySelector("#login")?.classList.add("hidden");
      document.querySelector("#app")?.classList.remove("hidden");
      window.SMART_RISK_AUTH_DIAGNOSTIC={stage:"application-error",message:String(error.message||error),at:new Date().toISOString()};
    }finally{loading=false;setLoginBusy(false)}
  }
  async function handle(user){
    try{
      window.SMART_RISK_AUTH_DIAGNOSTIC={stage:"reading-profile",email:user.email,uid:user.uid,at:new Date().toISOString()};
      const profile=await readProfile(user);
      if(!profile){
        rememberLoginMessage("La cuenta existe, pero no tiene un perfil en Firestore con el mismo UID.");
        window.SMART_RISK_AUTH_DIAGNOSTIC={stage:"profile-missing",email:user.email,uid:user.uid,at:new Date().toISOString()};
        await auth.signOut();
        return;
      }
      if(normalizeState(profile.estado)!=="activo"){
        rememberLoginMessage(`El perfil existe, pero su estado es “${profile.estado||"sin definir"}”. Debe estar Activo.`);
        window.SMART_RISK_AUTH_DIAGNOSTIC={stage:"profile-inactive",email:user.email,uid:user.uid,profileState:profile.estado,at:new Date().toISOString()};
        await auth.signOut();
        return;
      }
      await loadApplication(user,profile);
    }catch(error){
      console.error("No fue posible leer el perfil autorizado",error);
      const code=String(error?.code||"");
      const message=code==="permission-denied"||code==="firestore/permission-denied"
        ?"Firebase Authentication aceptó la cuenta, pero las reglas de Firestore impiden leer su perfil."
        :`No fue posible cargar el perfil autorizado${code?` (${code})`:""}.`;
      rememberLoginMessage(message);
      window.SMART_RISK_AUTH_DIAGNOSTIC={stage:"profile-read-error",code,message:String(error?.message||error),at:new Date().toISOString()};
      await auth.signOut();
    }
  }

  $("#loginForm").onsubmit=async event=>{
    event.preventDefault();
    pendingLoginMessage="";
    loginMessage("");
    setLoginBusy(true);
    const email=normalizeEmail($("#email").value);
    try{
      window.SMART_RISK_AUTH_DIAGNOSTIC={stage:"signing-in",email,at:new Date().toISOString()};
      const result=await auth.signInWithEmailAndPassword(email,$("#password").value);
      $("#password").value="";
      window.SMART_RISK_AUTH_DIAGNOSTIC={stage:"authenticated",email:result.user.email,uid:result.user.uid,at:new Date().toISOString()};
    }catch(error){
      const message=authErrorMessage(error);
      rememberLoginMessage(message);
      window.SMART_RISK_AUTH_DIAGNOSTIC={stage:"authentication-error",code:String(error?.code||""),message:String(error?.message||error),email,at:new Date().toISOString()};
      setLoginBusy(false);
    }
  };
  $("#showRecovery").onclick=async()=>{
    const email=normalizeEmail($("#email").value);
    if(!email){rememberLoginMessage("Escribe tu correo para recibir el enlace.");$("#email").focus();return}
    try{await auth.sendPasswordResetEmail(email,{url:location.origin+location.pathname})}catch{}
    rememberLoginMessage("Si el correo está registrado, recibirás un enlace para definir una nueva contraseña.");
  };
  $("#logout").onclick=()=>auth.signOut();
  $("#changePassword").onclick=async()=>{
    const email=normalizeEmail(auth.currentUser?.email);if(!email)return;
    try{await auth.sendPasswordResetEmail(email,{url:location.origin+location.pathname})}catch{}
    alert("Se solicitó un enlace para definir una nueva contraseña.");
  };
  auth.onAuthStateChanged(async user=>{
    if(user){await handle(user);return}
    if(loaded){localStorage.removeItem("smartrisk-cz5-data-v1");location.reload();return}
    showLogin();
    setLoginBusy(false);
  });
  window.SMART_RISK_ACCESS_GATE={version:"14.4.3",mode:"unified-application-by-scope",support:"Soporte institucional CZ5"};
})();
